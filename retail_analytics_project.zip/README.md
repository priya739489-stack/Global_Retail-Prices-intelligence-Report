# Global Retail Price Intelligence

## Objective
Analyze retail product prices and explore price prediction.

## Dataset
Retail product pricing dataset supplied for this project.

## Methodology
1. Data quality checks and cleaning
2. Exploratory data analysis with five charts
3. EUR-only price regression
4. Business recommendations and limitations

## Model results
- MAE: 1.519
- RMSE: 2.394
- R2: 0.052
- Baseline MAE: 1.550

The model only slightly outperforms the baseline.
Its predictive performance is weak and should not be
used for operational pricing decisions without further
validation and improvement.

## Run dashboard
Install requirements, then run:
streamlit run app.py
